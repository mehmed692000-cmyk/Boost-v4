
package com.surya.gamebooster

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tvStatus = TextView(this)
        tvStatus.text = "SuryaProject v2\nDurum: Beklemede"
        setContentView(tvStatus)

        // DND izni kontrolü
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            startActivity(intent)
        }

        // Kullanım erişim izni kontrolü
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            "android:get_usage_stats",
            android.os.Process.myUid(), packageName
        )
        if (mode != AppOpsManager.MODE_ALLOWED) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        // Servisi başlat
        startService(Intent(this, UsageMonitorService::class.java))

        // Yayın alıcıları
        val filter = IntentFilter().apply {
            addAction("BOOST_NOW")
            addAction("BOOST_END")
        }
        registerReceiver(boostReceiver, filter)
    }

    private val boostReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "BOOST_NOW" -> runBoost()
                "BOOST_END" -> tvStatus.append("\nOyun kapandı, ayarlar normale döndü.")
            }
        }
    }

    private fun runBoost() {
        tvStatus.append("\nOyun algılandı! Performans artırılıyor...")
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        try {
            val pm = PowerManager::class.java.getDeclaredMethod("setPowerSaveMode", Boolean::class.javaPrimitiveType)
            pm.invoke(false)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(boostReceiver)
    }
}
